--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 11.2
-- Dumped by pg_dump version 11.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE sambilproyectoferia;
--
-- Name: sambilproyectoferia; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE sambilproyectoferia WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'Spanish_Spain.1252' LC_CTYPE = 'Spanish_Spain.1252';


ALTER DATABASE sambilproyectoferia OWNER TO postgres;

\connect sambilproyectoferia

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: cantidadocupacionesmesa(integer, date); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.cantidadocupacionesmesa(mesa integer, fecha date) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
	DECLARE
		datum BIGINT;
	BEGIN
		SELECT COUNT(*) INTO datum
			FROM estadomesa
			WHERE idmesa=mesa
			AND ocupado=true
			AND EXTRACT(DAY FROM fechaestado)=EXTRACT(DAY FROM fecha)
			AND EXTRACT(MONTH FROM fechaestado)=EXTRACT(MONTH FROM fecha)
			AND EXTRACT(YEAR FROM fechaestado)=EXTRACT(YEAR FROM fecha);
		RETURN datum;
	END; $$;


ALTER FUNCTION public.cantidadocupacionesmesa(mesa integer, fecha date) OWNER TO postgres;

--
-- Name: verificarsentadoenmesa(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.verificarsentadoenmesa(smartphone integer) RETURNS character varying
    LANGUAGE plpgsql
    AS $$
	BEGIN
		IF(smartphone IN (
			SELECT idsmartphone
			FROM monitoreomesa
			WHERE idsmartphone=smartphone
			AND fechadesocupado IS NULL
			ORDER BY fechaocupado DESC
			LIMIT 1
		))THEN
			RAISE INFO 'El smartphone se encuentra en una mesa de feria';
			RETURN 'El smartphone se encuentra en una mesa de feria';
		ELSE
			RAISE INFO 'El smartphone no se encuentra en una mesa de feria';
			RETURN 'El smartphone no se encuentra en una mesa de feria';
	END IF;
	RETURN '';
	END; $$;


ALTER FUNCTION public.verificarsentadoenmesa(smartphone integer) OWNER TO postgres;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: beacon; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.beacon (
    id integer NOT NULL,
    macaddress character varying(40) NOT NULL
);


ALTER TABLE public.beacon OWNER TO postgres;

--
-- Name: beacon_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.beacon_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.beacon_id_seq OWNER TO postgres;

--
-- Name: beacon_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.beacon_id_seq OWNED BY public.beacon.id;


--
-- Name: camara; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.camara (
    id integer NOT NULL,
    macaddress character varying(40) NOT NULL
);


ALTER TABLE public.camara OWNER TO postgres;

--
-- Name: camara_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.camara_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.camara_id_seq OWNER TO postgres;

--
-- Name: camara_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.camara_id_seq OWNED BY public.camara.id;


--
-- Name: monitoreomesa; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.monitoreomesa (
    id integer NOT NULL,
    idsmartphone integer NOT NULL,
    idmesa integer NOT NULL,
    fechaocupado timestamp without time zone NOT NULL,
    fechadesocupado timestamp without time zone
);


ALTER TABLE public.monitoreomesa OWNER TO postgres;

--
-- Name: cantidadmesasocupadas; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.cantidadmesasocupadas AS
 SELECT count(*) AS mesasocupadas
   FROM public.monitoreomesa
  WHERE (monitoreomesa.fechadesocupado IS NULL);


ALTER TABLE public.cantidadmesasocupadas OWNER TO postgres;

--
-- Name: estadomesa; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.estadomesa (
    id integer NOT NULL,
    idmesa integer NOT NULL,
    fechaestado timestamp without time zone NOT NULL,
    ocupado boolean NOT NULL
);


ALTER TABLE public.estadomesa OWNER TO postgres;

--
-- Name: estadomesa_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.estadomesa_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.estadomesa_id_seq OWNER TO postgres;

--
-- Name: estadomesa_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.estadomesa_id_seq OWNED BY public.estadomesa.id;


--
-- Name: mesa; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mesa (
    id integer NOT NULL
);


ALTER TABLE public.mesa OWNER TO postgres;

--
-- Name: mesa_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.mesa_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.mesa_id_seq OWNER TO postgres;

--
-- Name: mesa_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.mesa_id_seq OWNED BY public.mesa.id;


--
-- Name: monitoreomesa_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.monitoreomesa_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.monitoreomesa_id_seq OWNER TO postgres;

--
-- Name: monitoreomesa_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.monitoreomesa_id_seq OWNED BY public.monitoreomesa.id;


--
-- Name: sensormesa; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sensormesa (
    id integer NOT NULL,
    macaddress character varying(40) NOT NULL,
    idmesa integer
);


ALTER TABLE public.sensormesa OWNER TO postgres;

--
-- Name: sensormesa_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sensormesa_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sensormesa_id_seq OWNER TO postgres;

--
-- Name: sensormesa_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sensormesa_id_seq OWNED BY public.sensormesa.id;


--
-- Name: smartphone; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.smartphone (
    id integer NOT NULL,
    macaddress character varying(40) NOT NULL
);


ALTER TABLE public.smartphone OWNER TO postgres;

--
-- Name: smartphone_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.smartphone_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.smartphone_id_seq OWNER TO postgres;

--
-- Name: smartphone_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.smartphone_id_seq OWNED BY public.smartphone.id;


--
-- Name: beacon id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.beacon ALTER COLUMN id SET DEFAULT nextval('public.beacon_id_seq'::regclass);


--
-- Name: camara id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.camara ALTER COLUMN id SET DEFAULT nextval('public.camara_id_seq'::regclass);


--
-- Name: estadomesa id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.estadomesa ALTER COLUMN id SET DEFAULT nextval('public.estadomesa_id_seq'::regclass);


--
-- Name: mesa id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mesa ALTER COLUMN id SET DEFAULT nextval('public.mesa_id_seq'::regclass);


--
-- Name: monitoreomesa id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.monitoreomesa ALTER COLUMN id SET DEFAULT nextval('public.monitoreomesa_id_seq'::regclass);


--
-- Name: sensormesa id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sensormesa ALTER COLUMN id SET DEFAULT nextval('public.sensormesa_id_seq'::regclass);


--
-- Name: smartphone id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.smartphone ALTER COLUMN id SET DEFAULT nextval('public.smartphone_id_seq'::regclass);


--
-- Data for Name: beacon; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.beacon (id, macaddress) FROM stdin;
\.
COPY public.beacon (id, macaddress) FROM '$$PATH$$/2874.dat';

--
-- Data for Name: camara; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.camara (id, macaddress) FROM stdin;
\.
COPY public.camara (id, macaddress) FROM '$$PATH$$/2876.dat';

--
-- Data for Name: estadomesa; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.estadomesa (id, idmesa, fechaestado, ocupado) FROM stdin;
\.
COPY public.estadomesa (id, idmesa, fechaestado, ocupado) FROM '$$PATH$$/2879.dat';

--
-- Data for Name: mesa; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mesa (id) FROM stdin;
\.
COPY public.mesa (id) FROM '$$PATH$$/2881.dat';

--
-- Data for Name: monitoreomesa; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.monitoreomesa (id, idsmartphone, idmesa, fechaocupado, fechadesocupado) FROM stdin;
\.
COPY public.monitoreomesa (id, idsmartphone, idmesa, fechaocupado, fechadesocupado) FROM '$$PATH$$/2878.dat';

--
-- Data for Name: sensormesa; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sensormesa (id, macaddress, idmesa) FROM stdin;
\.
COPY public.sensormesa (id, macaddress, idmesa) FROM '$$PATH$$/2884.dat';

--
-- Data for Name: smartphone; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.smartphone (id, macaddress) FROM stdin;
\.
COPY public.smartphone (id, macaddress) FROM '$$PATH$$/2886.dat';

--
-- Name: beacon_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.beacon_id_seq', 21, true);


--
-- Name: camara_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.camara_id_seq', 21, true);


--
-- Name: estadomesa_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.estadomesa_id_seq', 6716, true);


--
-- Name: mesa_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.mesa_id_seq', 1, false);


--
-- Name: monitoreomesa_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.monitoreomesa_id_seq', 2491, true);


--
-- Name: sensormesa_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sensormesa_id_seq', 10, true);


--
-- Name: smartphone_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.smartphone_id_seq', 1, false);


--
-- Name: beacon beacon_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.beacon
    ADD CONSTRAINT beacon_pkey PRIMARY KEY (id);


--
-- Name: camara camara_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.camara
    ADD CONSTRAINT camara_pkey PRIMARY KEY (id);


--
-- Name: estadomesa estadomesa_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.estadomesa
    ADD CONSTRAINT estadomesa_pkey PRIMARY KEY (id);


--
-- Name: mesa mesa_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mesa
    ADD CONSTRAINT mesa_pkey PRIMARY KEY (id);


--
-- Name: monitoreomesa monitoreomesa_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.monitoreomesa
    ADD CONSTRAINT monitoreomesa_pkey PRIMARY KEY (id);


--
-- Name: sensormesa sensormesa_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sensormesa
    ADD CONSTRAINT sensormesa_pkey PRIMARY KEY (id);


--
-- Name: smartphone smartphone_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.smartphone
    ADD CONSTRAINT smartphone_pkey PRIMARY KEY (id);


--
-- Name: estadomesa fkey_mesa_estadomesa; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.estadomesa
    ADD CONSTRAINT fkey_mesa_estadomesa FOREIGN KEY (idmesa) REFERENCES public.mesa(id);


--
-- Name: monitoreomesa fkey_mesa_monitoreomesa; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.monitoreomesa
    ADD CONSTRAINT fkey_mesa_monitoreomesa FOREIGN KEY (idmesa) REFERENCES public.mesa(id);


--
-- Name: sensormesa fkey_mesa_sensormesa; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sensormesa
    ADD CONSTRAINT fkey_mesa_sensormesa FOREIGN KEY (idmesa) REFERENCES public.mesa(id);


--
-- Name: monitoreomesa fkey_smartphone_monitoreomesa; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.monitoreomesa
    ADD CONSTRAINT fkey_smartphone_monitoreomesa FOREIGN KEY (idsmartphone) REFERENCES public.smartphone(id);


--
-- PostgreSQL database dump complete
--

