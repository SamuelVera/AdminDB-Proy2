--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 11.2
-- Dumped by pg_dump version 11.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE sambilproyectoventas;
--
-- Name: sambilproyectoventas; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE sambilproyectoventas WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'Spanish_Spain.1252' LC_CTYPE = 'Spanish_Spain.1252';


ALTER DATABASE sambilproyectoventas OWNER TO postgres;

\connect sambilproyectoventas

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: dblink; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS dblink WITH SCHEMA public;


--
-- Name: EXTENSION dblink; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION dblink IS 'connect to other PostgreSQL databases from within a database';


--
-- Name: gastosmartphone(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.gastosmartphone(smartphone integer) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
	DECLARE
			monto BIGINT;
	BEGIN
		SELECT CAST(SUM(f.monto) AS BIGINT) INTO monto 
			FROM factura AS f
			WHERE 
				EXTRACT(MONTH FROM fechacompra) = EXTRACT(MONTH FROM current_timestamp)-1
				AND
				EXTRACT(YEAR FROM fechacompra) = EXTRACT(YEAR FROM current_timestamp)
				AND f.idsmartphone IS NOT NULL
				AND f.idsmartphone = smartphone;
		RETURN monto;
	END; $$;


ALTER FUNCTION public.gastosmartphone(smartphone integer) OWNER TO postgres;

--
-- Name: insertprimerfacturadia(integer, timestamp without time zone); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.insertprimerfacturadia(n integer, f timestamp without time zone) RETURNS void
    LANGUAGE plpgsql
    AS $$
	BEGIN
		INSERT INTO primerfacturadia(idfactura, fecha)
		VALUES(n,f);
	END; $$;


ALTER FUNCTION public.insertprimerfacturadia(n integer, f timestamp without time zone) OWNER TO postgres;

--
-- Name: localessectorpiso(integer, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.localessectorpiso(numerosector integer, numeropiso integer) RETURNS TABLE(sector character varying, piso character varying, codigolocal character varying, franquicias character varying)
    LANGUAGE plpgsql
    AS $$
	BEGIN
		RETURN QUERY(
			SELECT s.nombre,
			p.nombre,
			l.codigo,
			f.nombre
			FROM local AS l
			INNER JOIN franquicia AS f
				ON l.idfranquicia=f.id
			INNER JOIN piso AS p
				ON l.idpiso=p.numero
			INNER JOIN sector AS s
				ON l.idsector=s.id
			WHERE
				l.idsector=numerosector
				AND p.numero=numeropiso
		);
	END; $$;


ALTER FUNCTION public.localessectorpiso(numerosector integer, numeropiso integer) OWNER TO postgres;

--
-- Name: primerafacturames(integer, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.primerafacturames(mes integer, anio integer) RETURNS TABLE(idfactura integer, fecha timestamp without time zone, ci integer, monto integer)
    LANGUAGE plpgsql
    AS $$
	BEGIN
		RETURN QUERY(
		SELECT f.numero, f.fechacompra, f.cicomprador, f.monto FROM factura AS f
		INNER JOIN primerfacturadia AS pf
			ON pf.idfactura = f.numero
		WHERE EXTRACT(MONTH FROM f.fechacompra)=mes
		AND EXTRACT(YEAR FROM f.fechacompra)=anio);
	END; $$;


ALTER FUNCTION public.primerafacturames(mes integer, anio integer) OWNER TO postgres;

--
-- Name: primerfacturadia(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.primerfacturadia() RETURNS trigger
    LANGUAGE plpgsql
    AS $$	BEGIN
		IF(NEW.idsmartphone IS NOT NULL) THEN
			IF(
				NOT EXISTS 
				(
					SELECT numero
					FROM factura
					WHERE EXTRACT(DAY FROM fechacompra) = EXTRACT(DAY FROM NEW.fechacompra) 
					AND EXTRACT(MONTH FROM fechacompra) = EXTRACT(MONTH FROM NEW.fechacompra)
					AND EXTRACT(YEAR FROM fechacompra) = EXTRACT(YEAR FROM NEW.fechacompra)
					AND idsmartphone IS NOT NULL
				)
			)THEN
				EXECUTE insertprimerfacturadia(NEW.numero,NEW.fechacompra);
			END IF;
		END IF;
        RETURN NEW;
    END; $$;


ALTER FUNCTION public.primerfacturadia() OWNER TO postgres;

--
-- Name: ventasdetienda(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.ventasdetienda(idfran integer) RETURNS TABLE(nombre character varying, local character varying, montoenventas bigint)
    LANGUAGE plpgsql
    AS $$
	BEGIN
		RETURN QUERY (
			SELECT fr.nombre, l.codigo, CAST( SUM(f.monto) AS BIGINT) AS montoenventas
			FROM local AS l
			INNER JOIN factura AS f
				ON l.id = f.idlocal
			INNER JOIN franquicia AS fr
				ON fr.id = l.idfranquicia
			WHERE l.idfranquicia=idfran
			GROUP BY l.id, fr.id
			ORDER BY montoenventas DESC
		);
	END; $$;


ALTER FUNCTION public.ventasdetienda(idfran integer) OWNER TO postgres;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: beacon; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.beacon (
    id integer NOT NULL,
    macaddress character varying(40) NOT NULL
);


ALTER TABLE public.beacon OWNER TO postgres;

--
-- Name: beacon_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.beacon_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.beacon_id_seq OWNER TO postgres;

--
-- Name: beacon_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.beacon_id_seq OWNED BY public.beacon.id;


--
-- Name: camara; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.camara (
    id integer NOT NULL,
    macaddress character varying(40) NOT NULL
);


ALTER TABLE public.camara OWNER TO postgres;

--
-- Name: camara_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.camara_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.camara_id_seq OWNER TO postgres;

--
-- Name: camara_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.camara_id_seq OWNED BY public.camara.id;


--
-- Name: centrocomercial; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.centrocomercial (
    id integer NOT NULL,
    nombre character varying(50) NOT NULL
);


ALTER TABLE public.centrocomercial OWNER TO postgres;

--
-- Name: centrocomercial_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.centrocomercial_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.centrocomercial_id_seq OWNER TO postgres;

--
-- Name: centrocomercial_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.centrocomercial_id_seq OWNED BY public.centrocomercial.id;


--
-- Name: factura; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.factura (
    numero integer NOT NULL,
    cicomprador integer NOT NULL,
    idlocal integer NOT NULL,
    monto integer NOT NULL,
    fechacompra timestamp(4) without time zone NOT NULL,
    idsmartphone integer
);


ALTER TABLE public.factura OWNER TO postgres;

--
-- Name: compra_numero_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.compra_numero_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.compra_numero_seq OWNER TO postgres;

--
-- Name: compra_numero_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.compra_numero_seq OWNED BY public.factura.numero;


--
-- Name: franquicia; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.franquicia (
    id integer NOT NULL,
    nombre character varying(40) NOT NULL
);


ALTER TABLE public.franquicia OWNER TO postgres;

--
-- Name: franquicia_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.franquicia_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.franquicia_id_seq OWNER TO postgres;

--
-- Name: franquicia_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.franquicia_id_seq OWNED BY public.franquicia.id;


--
-- Name: local; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.local (
    id integer NOT NULL,
    codigo character varying(40) NOT NULL,
    idpiso integer NOT NULL,
    idsector integer NOT NULL,
    idfranquicia integer NOT NULL
);


ALTER TABLE public.local OWNER TO postgres;

--
-- Name: local_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.local_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.local_id_seq OWNER TO postgres;

--
-- Name: local_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.local_id_seq OWNED BY public.local.id;


--
-- Name: piso; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.piso (
    numero integer NOT NULL,
    nombre character varying(30) NOT NULL,
    idcc integer NOT NULL
);


ALTER TABLE public.piso OWNER TO postgres;

--
-- Name: porcentajeventassmartphone; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.porcentajeventassmartphone AS
 SELECT round((((( SELECT count(*) AS count
           FROM public.factura
          WHERE (factura.idsmartphone IS NULL)))::numeric * (100)::numeric) / (( SELECT count(*) AS count
           FROM public.factura))::numeric), 2) AS sinsmartphone,
    round((((( SELECT count(*) AS count
           FROM public.factura
          WHERE (factura.idsmartphone IS NOT NULL)))::numeric * (100)::numeric) / (( SELECT count(*) AS count
           FROM public.factura))::numeric), 2) AS consmartphone;


ALTER TABLE public.porcentajeventassmartphone OWNER TO postgres;

--
-- Name: primerfacturadia; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.primerfacturadia (
    idfactura integer NOT NULL,
    fecha timestamp without time zone NOT NULL
);


ALTER TABLE public.primerfacturadia OWNER TO postgres;

--
-- Name: primerasventasultimomes; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.primerasventasultimomes AS
 SELECT pf.idfactura AS "numeroFactura",
    pf.fecha,
    f.cicomprador AS comprador,
    f.monto
   FROM (public.primerfacturadia pf
     JOIN public.factura f ON ((pf.idfactura = f.numero)))
  WHERE ((date_part('month'::text, pf.fecha) = (date_part('month'::text, CURRENT_DATE) - (1)::double precision)) AND (date_part('year'::text, pf.fecha) = date_part('year'::text, CURRENT_DATE)))
  ORDER BY pf.fecha;


ALTER TABLE public.primerasventasultimomes OWNER TO postgres;

--
-- Name: primerfacturadia_idfactura_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.primerfacturadia_idfactura_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.primerfacturadia_idfactura_seq OWNER TO postgres;

--
-- Name: primerfacturadia_idfactura_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.primerfacturadia_idfactura_seq OWNED BY public.primerfacturadia.idfactura;


--
-- Name: sector; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sector (
    id integer NOT NULL,
    nombre character varying(30) NOT NULL,
    idcc integer NOT NULL
);


ALTER TABLE public.sector OWNER TO postgres;

--
-- Name: smartphone; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.smartphone (
    id integer NOT NULL,
    macaddress character varying(40) NOT NULL
);


ALTER TABLE public.smartphone OWNER TO postgres;

--
-- Name: smartphone_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.smartphone_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.smartphone_id_seq OWNER TO postgres;

--
-- Name: smartphone_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.smartphone_id_seq OWNED BY public.smartphone.id;


--
-- Name: top5franquiciasventas; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.top5franquiciasventas AS
SELECT
    NULL::character varying(40) AS nombre,
    NULL::bigint AS total;


ALTER TABLE public.top5franquiciasventas OWNER TO postgres;

--
-- Name: beacon id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.beacon ALTER COLUMN id SET DEFAULT nextval('public.beacon_id_seq'::regclass);


--
-- Name: camara id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.camara ALTER COLUMN id SET DEFAULT nextval('public.camara_id_seq'::regclass);


--
-- Name: centrocomercial id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.centrocomercial ALTER COLUMN id SET DEFAULT nextval('public.centrocomercial_id_seq'::regclass);


--
-- Name: factura numero; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.factura ALTER COLUMN numero SET DEFAULT nextval('public.compra_numero_seq'::regclass);


--
-- Name: franquicia id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.franquicia ALTER COLUMN id SET DEFAULT nextval('public.franquicia_id_seq'::regclass);


--
-- Name: local id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.local ALTER COLUMN id SET DEFAULT nextval('public.local_id_seq'::regclass);


--
-- Name: primerfacturadia idfactura; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.primerfacturadia ALTER COLUMN idfactura SET DEFAULT nextval('public.primerfacturadia_idfactura_seq'::regclass);


--
-- Name: smartphone id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.smartphone ALTER COLUMN id SET DEFAULT nextval('public.smartphone_id_seq'::regclass);


--
-- Data for Name: beacon; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.beacon (id, macaddress) FROM stdin;
\.
COPY public.beacon (id, macaddress) FROM '$$PATH$$/2961.dat';

--
-- Data for Name: camara; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.camara (id, macaddress) FROM stdin;
\.
COPY public.camara (id, macaddress) FROM '$$PATH$$/2963.dat';

--
-- Data for Name: centrocomercial; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.centrocomercial (id, nombre) FROM stdin;
\.
COPY public.centrocomercial (id, nombre) FROM '$$PATH$$/2965.dat';

--
-- Data for Name: factura; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.factura (numero, cicomprador, idlocal, monto, fechacompra, idsmartphone) FROM stdin;
\.
COPY public.factura (numero, cicomprador, idlocal, monto, fechacompra, idsmartphone) FROM '$$PATH$$/2968.dat';

--
-- Data for Name: franquicia; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.franquicia (id, nombre) FROM stdin;
\.
COPY public.franquicia (id, nombre) FROM '$$PATH$$/2970.dat';

--
-- Data for Name: local; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.local (id, codigo, idpiso, idsector, idfranquicia) FROM stdin;
\.
COPY public.local (id, codigo, idpiso, idsector, idfranquicia) FROM '$$PATH$$/2967.dat';

--
-- Data for Name: piso; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.piso (numero, nombre, idcc) FROM stdin;
\.
COPY public.piso (numero, nombre, idcc) FROM '$$PATH$$/2974.dat';

--
-- Data for Name: primerfacturadia; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.primerfacturadia (idfactura, fecha) FROM stdin;
\.
COPY public.primerfacturadia (idfactura, fecha) FROM '$$PATH$$/2975.dat';

--
-- Data for Name: sector; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sector (id, nombre, idcc) FROM stdin;
\.
COPY public.sector (id, nombre, idcc) FROM '$$PATH$$/2973.dat';

--
-- Data for Name: smartphone; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.smartphone (id, macaddress) FROM stdin;
\.
COPY public.smartphone (id, macaddress) FROM '$$PATH$$/2977.dat';

--
-- Name: beacon_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.beacon_id_seq', 21, true);


--
-- Name: camara_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.camara_id_seq', 21, true);


--
-- Name: centrocomercial_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.centrocomercial_id_seq', 1, true);


--
-- Name: compra_numero_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.compra_numero_seq', 5339, true);


--
-- Name: franquicia_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.franquicia_id_seq', 9, true);


--
-- Name: local_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.local_id_seq', 17, true);


--
-- Name: primerfacturadia_idfactura_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.primerfacturadia_idfactura_seq', 1, false);


--
-- Name: smartphone_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.smartphone_id_seq', 1, false);


--
-- Name: beacon beacon_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.beacon
    ADD CONSTRAINT beacon_pkey PRIMARY KEY (id);


--
-- Name: camara camara_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.camara
    ADD CONSTRAINT camara_pkey PRIMARY KEY (id);


--
-- Name: centrocomercial centrocomercial_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.centrocomercial
    ADD CONSTRAINT centrocomercial_pkey PRIMARY KEY (id);


--
-- Name: factura factura_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.factura
    ADD CONSTRAINT factura_pkey PRIMARY KEY (numero);


--
-- Name: franquicia franquicia_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.franquicia
    ADD CONSTRAINT franquicia_pkey PRIMARY KEY (id);


--
-- Name: local local_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.local
    ADD CONSTRAINT local_pkey PRIMARY KEY (id);


--
-- Name: piso piso_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.piso
    ADD CONSTRAINT piso_pkey PRIMARY KEY (numero);


--
-- Name: primerfacturadia primerfacturadia_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.primerfacturadia
    ADD CONSTRAINT primerfacturadia_pkey PRIMARY KEY (idfactura);


--
-- Name: sector sector_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sector
    ADD CONSTRAINT sector_pkey PRIMARY KEY (id);


--
-- Name: smartphone smartphone_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.smartphone
    ADD CONSTRAINT smartphone_pkey PRIMARY KEY (id);


--
-- Name: top5franquiciasventas _RETURN; Type: RULE; Schema: public; Owner: postgres
--

CREATE OR REPLACE VIEW public.top5franquiciasventas AS
 SELECT fr.nombre,
    sum(f.monto) AS total
   FROM ((public.factura f
     JOIN public.local l ON ((f.idlocal = l.id)))
     JOIN public.franquicia fr ON ((l.idfranquicia = fr.id)))
  WHERE ((date_part('month'::text, f.fechacompra) = (date_part('month'::text, CURRENT_DATE) - (1)::double precision)) AND (date_part('year'::text, f.fechacompra) = date_part('year'::text, CURRENT_DATE)))
  GROUP BY fr.id
  ORDER BY (sum(f.monto)) DESC
 LIMIT 5;


--
-- Name: factura primerfacturadiatrigger; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER primerfacturadiatrigger BEFORE INSERT ON public.factura FOR EACH ROW EXECUTE PROCEDURE public.primerfacturadia();


--
-- Name: sector fkey_cc_sector; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sector
    ADD CONSTRAINT fkey_cc_sector FOREIGN KEY (idcc) REFERENCES public.centrocomercial(id);


--
-- Name: local fkey_franquicia_local; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.local
    ADD CONSTRAINT fkey_franquicia_local FOREIGN KEY (idfranquicia) REFERENCES public.franquicia(id);


--
-- Name: factura fkey_local_factura; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.factura
    ADD CONSTRAINT fkey_local_factura FOREIGN KEY (idlocal) REFERENCES public.local(id);


--
-- Name: piso fkey_piso_cc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.piso
    ADD CONSTRAINT fkey_piso_cc FOREIGN KEY (idcc) REFERENCES public.centrocomercial(id);


--
-- Name: local fkey_piso_local; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.local
    ADD CONSTRAINT fkey_piso_local FOREIGN KEY (idpiso) REFERENCES public.piso(numero);


--
-- Name: local fkey_sector_local; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.local
    ADD CONSTRAINT fkey_sector_local FOREIGN KEY (idsector) REFERENCES public.sector(id);


--
-- Name: factura fkey_smartphone_factura; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.factura
    ADD CONSTRAINT fkey_smartphone_factura FOREIGN KEY (idsmartphone) REFERENCES public.smartphone(id);


--
-- Name: primerfacturadia key_factura_primerfacturadia; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.primerfacturadia
    ADD CONSTRAINT key_factura_primerfacturadia FOREIGN KEY (idfactura) REFERENCES public.factura(numero) DEFERRABLE INITIALLY DEFERRED;


--
-- PostgreSQL database dump complete
--

