--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 11.2
-- Dumped by pg_dump version 11.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE sambilproyecto_datawarehouse;
--
-- Name: sambilproyecto_datawarehouse; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE sambilproyecto_datawarehouse WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'Spanish_Spain.1252' LC_CTYPE = 'Spanish_Spain.1252';


ALTER DATABASE sambilproyecto_datawarehouse OWNER TO postgres;

\connect sambilproyecto_datawarehouse

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: dimensionfecha; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dimensionfecha (
    dimensiondate timestamp without time zone,
    year smallint NOT NULL,
    quarter double precision,
    month smallint NOT NULL,
    day smallint NOT NULL,
    weekday smallint,
    monthname text,
    dayname text,
    dayinyear double precision
);


ALTER TABLE public.dimensionfecha OWNER TO postgres;

--
-- Name: dimensionfranquicia; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dimensionfranquicia (
    id integer,
    nombre character varying(40)
);


ALTER TABLE public.dimensionfranquicia OWNER TO postgres;

--
-- Name: dimensionlocal; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dimensionlocal (
    id integer,
    codigo character varying(40),
    piso integer,
    sector character varying(30)
);


ALTER TABLE public.dimensionlocal OWNER TO postgres;

--
-- Name: ventasdiariaslocal; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ventasdiariaslocal (
    dayinyear double precision NOT NULL,
    year smallint NOT NULL,
    local integer NOT NULL,
    monto double precision
);


ALTER TABLE public.ventasdiariaslocal OWNER TO postgres;

--
-- Name: ventasmensualeslocal; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ventasmensualeslocal (
    local integer NOT NULL,
    monto double precision,
    month double precision NOT NULL,
    year double precision NOT NULL
);


ALTER TABLE public.ventasmensualeslocal OWNER TO postgres;

--
-- Data for Name: dimensionfecha; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dimensionfecha (dimensiondate, year, quarter, month, day, weekday, monthname, dayname, dayinyear) FROM stdin;
\.
COPY public.dimensionfecha (dimensiondate, year, quarter, month, day, weekday, monthname, dayname, dayinyear) FROM '$$PATH$$/2827.dat';

--
-- Data for Name: dimensionfranquicia; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dimensionfranquicia (id, nombre) FROM stdin;
\.
COPY public.dimensionfranquicia (id, nombre) FROM '$$PATH$$/2829.dat';

--
-- Data for Name: dimensionlocal; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dimensionlocal (id, codigo, piso, sector) FROM stdin;
\.
COPY public.dimensionlocal (id, codigo, piso, sector) FROM '$$PATH$$/2828.dat';

--
-- Data for Name: ventasdiariaslocal; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ventasdiariaslocal (dayinyear, year, local, monto) FROM stdin;
\.
COPY public.ventasdiariaslocal (dayinyear, year, local, monto) FROM '$$PATH$$/2830.dat';

--
-- Data for Name: ventasmensualeslocal; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ventasmensualeslocal (local, monto, month, year) FROM stdin;
\.
COPY public.ventasmensualeslocal (local, monto, month, year) FROM '$$PATH$$/2831.dat';

--
-- Name: dimensionfecha dimensionfecha_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dimensionfecha
    ADD CONSTRAINT dimensionfecha_pkey PRIMARY KEY (year, month, day);


--
-- Name: ventasdiariaslocal ventasdiariaslocal_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ventasdiariaslocal
    ADD CONSTRAINT ventasdiariaslocal_pkey PRIMARY KEY (dayinyear, year, local);


--
-- Name: ventasmensualeslocal ventasmensualeslocal_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ventasmensualeslocal
    ADD CONSTRAINT ventasmensualeslocal_pkey PRIMARY KEY (local, month, year);


--
-- PostgreSQL database dump complete
--

