--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 11.2
-- Dumped by pg_dump version 11.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE sambilproyecto_datawarehouse;
--
-- Name: sambilproyecto_datawarehouse; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE sambilproyecto_datawarehouse WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'Spanish_Spain.1252' LC_CTYPE = 'Spanish_Spain.1252';


ALTER DATABASE sambilproyecto_datawarehouse OWNER TO postgres;

\connect sambilproyecto_datawarehouse

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: dimensionfecha; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dimensionfecha (
    dimensiondate timestamp without time zone,
    year smallint NOT NULL,
    quarter double precision,
    month smallint NOT NULL,
    day smallint NOT NULL,
    weekday smallint,
    monthname text,
    dayname text,
    dayinyear double precision
);


ALTER TABLE public.dimensionfecha OWNER TO postgres;

--
-- Name: dimensionfranquicia; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dimensionfranquicia (
    id integer,
    nombre character varying(40)
);


ALTER TABLE public.dimensionfranquicia OWNER TO postgres;

--
-- Name: dimensionlocal; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dimensionlocal (
    id integer,
    codigo character varying(40),
    piso integer,
    sector character varying(30)
);


ALTER TABLE public.dimensionlocal OWNER TO postgres;

--
-- Name: dimensionmesa; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dimensionmesa (
    id integer NOT NULL
);


ALTER TABLE public.dimensionmesa OWNER TO postgres;

--
-- Name: dimensionpiso; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dimensionpiso (
    numero integer NOT NULL,
    nombre character varying(30)
);


ALTER TABLE public.dimensionpiso OWNER TO postgres;

--
-- Name: dimensionsector; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dimensionsector (
    id integer NOT NULL,
    nombre character varying(30)
);


ALTER TABLE public.dimensionsector OWNER TO postgres;

--
-- Name: flujodiariolocal; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.flujodiariolocal (
    local integer NOT NULL,
    dayinyear double precision NOT NULL,
    year double precision NOT NULL,
    flujo bigint
);


ALTER TABLE public.flujodiariolocal OWNER TO postgres;

--
-- Name: flujodiariosectorpiso; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.flujodiariosectorpiso (
    sector integer NOT NULL,
    piso integer NOT NULL,
    dayinyear double precision NOT NULL,
    year double precision NOT NULL,
    cantidad bigint
);


ALTER TABLE public.flujodiariosectorpiso OWNER TO postgres;

--
-- Name: ventasdiariasfranquicia; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ventasdiariasfranquicia (
    franquicia integer NOT NULL,
    dayinyear double precision NOT NULL,
    year smallint NOT NULL,
    monto double precision
);


ALTER TABLE public.ventasdiariasfranquicia OWNER TO postgres;

--
-- Name: ventasdiariaslocal; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ventasdiariaslocal (
    dayinyear double precision NOT NULL,
    year smallint NOT NULL,
    local integer NOT NULL,
    monto double precision
);


ALTER TABLE public.ventasdiariaslocal OWNER TO postgres;

--
-- Name: ventasdiariassectorpiso; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ventasdiariassectorpiso (
    sector integer NOT NULL,
    piso integer NOT NULL,
    dayinyear double precision NOT NULL,
    year smallint NOT NULL,
    monto double precision
);


ALTER TABLE public.ventasdiariassectorpiso OWNER TO postgres;

--
-- Name: ventasmensualesfranquicia; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ventasmensualesfranquicia (
    franquicia integer NOT NULL,
    month double precision NOT NULL,
    year double precision NOT NULL,
    monto double precision
);


ALTER TABLE public.ventasmensualesfranquicia OWNER TO postgres;

--
-- Name: ventasmensualeslocal; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ventasmensualeslocal (
    local integer NOT NULL,
    monto double precision,
    month double precision NOT NULL,
    year double precision NOT NULL
);


ALTER TABLE public.ventasmensualeslocal OWNER TO postgres;

--
-- Name: ventasmensualessectorpiso; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ventasmensualessectorpiso (
    sector integer NOT NULL,
    piso integer NOT NULL,
    month double precision NOT NULL,
    year double precision NOT NULL,
    monto double precision
);


ALTER TABLE public.ventasmensualessectorpiso OWNER TO postgres;

--
-- Data for Name: dimensionfecha; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dimensionfecha (dimensiondate, year, quarter, month, day, weekday, monthname, dayname, dayinyear) FROM stdin;
\.
COPY public.dimensionfecha (dimensiondate, year, quarter, month, day, weekday, monthname, dayname, dayinyear) FROM '$$PATH$$/2883.dat';

--
-- Data for Name: dimensionfranquicia; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dimensionfranquicia (id, nombre) FROM stdin;
\.
COPY public.dimensionfranquicia (id, nombre) FROM '$$PATH$$/2882.dat';

--
-- Data for Name: dimensionlocal; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dimensionlocal (id, codigo, piso, sector) FROM stdin;
\.
COPY public.dimensionlocal (id, codigo, piso, sector) FROM '$$PATH$$/2881.dat';

--
-- Data for Name: dimensionmesa; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dimensionmesa (id) FROM stdin;
\.
COPY public.dimensionmesa (id) FROM '$$PATH$$/2894.dat';

--
-- Data for Name: dimensionpiso; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dimensionpiso (numero, nombre) FROM stdin;
\.
COPY public.dimensionpiso (numero, nombre) FROM '$$PATH$$/2885.dat';

--
-- Data for Name: dimensionsector; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dimensionsector (id, nombre) FROM stdin;
\.
COPY public.dimensionsector (id, nombre) FROM '$$PATH$$/2884.dat';

--
-- Data for Name: flujodiariolocal; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.flujodiariolocal (local, dayinyear, year, flujo) FROM stdin;
\.
COPY public.flujodiariolocal (local, dayinyear, year, flujo) FROM '$$PATH$$/2892.dat';

--
-- Data for Name: flujodiariosectorpiso; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.flujodiariosectorpiso (sector, piso, dayinyear, year, cantidad) FROM stdin;
\.
COPY public.flujodiariosectorpiso (sector, piso, dayinyear, year, cantidad) FROM '$$PATH$$/2893.dat';

--
-- Data for Name: ventasdiariasfranquicia; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ventasdiariasfranquicia (franquicia, dayinyear, year, monto) FROM stdin;
\.
COPY public.ventasdiariasfranquicia (franquicia, dayinyear, year, monto) FROM '$$PATH$$/2887.dat';

--
-- Data for Name: ventasdiariaslocal; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ventasdiariaslocal (dayinyear, year, local, monto) FROM stdin;
\.
COPY public.ventasdiariaslocal (dayinyear, year, local, monto) FROM '$$PATH$$/2888.dat';

--
-- Data for Name: ventasdiariassectorpiso; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ventasdiariassectorpiso (sector, piso, dayinyear, year, monto) FROM stdin;
\.
COPY public.ventasdiariassectorpiso (sector, piso, dayinyear, year, monto) FROM '$$PATH$$/2886.dat';

--
-- Data for Name: ventasmensualesfranquicia; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ventasmensualesfranquicia (franquicia, month, year, monto) FROM stdin;
\.
COPY public.ventasmensualesfranquicia (franquicia, month, year, monto) FROM '$$PATH$$/2889.dat';

--
-- Data for Name: ventasmensualeslocal; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ventasmensualeslocal (local, monto, month, year) FROM stdin;
\.
COPY public.ventasmensualeslocal (local, monto, month, year) FROM '$$PATH$$/2891.dat';

--
-- Data for Name: ventasmensualessectorpiso; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ventasmensualessectorpiso (sector, piso, month, year, monto) FROM stdin;
\.
COPY public.ventasmensualessectorpiso (sector, piso, month, year, monto) FROM '$$PATH$$/2890.dat';

--
-- Name: dimensionfecha dimensionfecha_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dimensionfecha
    ADD CONSTRAINT dimensionfecha_pkey PRIMARY KEY (year, month, day);


--
-- Name: dimensionmesa dimensionmesa_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dimensionmesa
    ADD CONSTRAINT dimensionmesa_pkey PRIMARY KEY (id);


--
-- Name: dimensionpiso dimensionpiso_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dimensionpiso
    ADD CONSTRAINT dimensionpiso_pkey PRIMARY KEY (numero);


--
-- Name: dimensionsector dimensionsector_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dimensionsector
    ADD CONSTRAINT dimensionsector_pkey PRIMARY KEY (id);


--
-- Name: flujodiariolocal flujodiariolocal_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flujodiariolocal
    ADD CONSTRAINT flujodiariolocal_pkey PRIMARY KEY (local, dayinyear, year);


--
-- Name: flujodiariosectorpiso flujodiariosectorpiso_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flujodiariosectorpiso
    ADD CONSTRAINT flujodiariosectorpiso_pkey PRIMARY KEY (sector, piso, dayinyear, year);


--
-- Name: ventasdiariasfranquicia ventasdiariasfranquicia_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ventasdiariasfranquicia
    ADD CONSTRAINT ventasdiariasfranquicia_pkey PRIMARY KEY (franquicia, dayinyear, year);


--
-- Name: ventasdiariaslocal ventasdiariaslocal_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ventasdiariaslocal
    ADD CONSTRAINT ventasdiariaslocal_pkey PRIMARY KEY (local, dayinyear, year);


--
-- Name: ventasdiariassectorpiso ventasdiariassectorpiso_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ventasdiariassectorpiso
    ADD CONSTRAINT ventasdiariassectorpiso_pkey PRIMARY KEY (sector, piso, dayinyear, year);


--
-- Name: ventasmensualesfranquicia ventasmensualesfranquicia_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ventasmensualesfranquicia
    ADD CONSTRAINT ventasmensualesfranquicia_pkey PRIMARY KEY (franquicia, month, year);


--
-- Name: ventasmensualeslocal ventasmensualeslocal_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ventasmensualeslocal
    ADD CONSTRAINT ventasmensualeslocal_pkey PRIMARY KEY (local, month, year);


--
-- Name: ventasmensualessectorpiso ventasmensualessectorpiso_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ventasmensualessectorpiso
    ADD CONSTRAINT ventasmensualessectorpiso_pkey PRIMARY KEY (sector, piso, month, year);


--
-- PostgreSQL database dump complete
--

