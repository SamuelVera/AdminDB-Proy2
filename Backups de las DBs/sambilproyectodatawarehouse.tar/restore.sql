--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 11.2
-- Dumped by pg_dump version 11.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE sambilproyectodatawarehouse;
--
-- Name: sambilproyectodatawarehouse; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE sambilproyectodatawarehouse WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'English_United States.1252' LC_CTYPE = 'English_United States.1252';


ALTER DATABASE sambilproyectodatawarehouse OWNER TO postgres;

\connect sambilproyectodatawarehouse

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: accesosdiariosedad; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.accesosdiariosedad (
    puerta integer NOT NULL,
    grupoedad double precision NOT NULL,
    year double precision NOT NULL,
    dayinyear double precision NOT NULL,
    cantidad bigint
);


ALTER TABLE public.accesosdiariosedad OWNER TO postgres;

--
-- Name: accesosdiariosporsexo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.accesosdiariosporsexo (
    puerta integer NOT NULL,
    year double precision NOT NULL,
    dayinyear double precision NOT NULL,
    sexo integer NOT NULL,
    cantidad bigint
);


ALTER TABLE public.accesosdiariosporsexo OWNER TO postgres;

--
-- Name: accesosdiariostotales; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.accesosdiariostotales (
    puerta integer NOT NULL,
    year double precision NOT NULL,
    dayinyear double precision NOT NULL,
    cantidad bigint
);


ALTER TABLE public.accesosdiariostotales OWNER TO postgres;

--
-- Name: accesosmensualedad; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.accesosmensualedad (
    puerta integer NOT NULL,
    grupoedad double precision NOT NULL,
    year double precision NOT NULL,
    month double precision NOT NULL,
    cantidad bigint
);


ALTER TABLE public.accesosmensualedad OWNER TO postgres;

--
-- Name: accesosmensualporsexo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.accesosmensualporsexo (
    puerta integer NOT NULL,
    year double precision NOT NULL,
    month double precision NOT NULL,
    sexo integer NOT NULL,
    cantidad bigint
);


ALTER TABLE public.accesosmensualporsexo OWNER TO postgres;

--
-- Name: accesosmensualtotales; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.accesosmensualtotales (
    puerta integer NOT NULL,
    year double precision NOT NULL,
    month double precision NOT NULL,
    cantidad bigint
);


ALTER TABLE public.accesosmensualtotales OWNER TO postgres;

--
-- Name: dimensionfecha; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dimensionfecha (
    dimensiondate timestamp without time zone,
    year smallint NOT NULL,
    quarter double precision,
    month smallint NOT NULL,
    day smallint NOT NULL,
    weekday smallint,
    monthname text,
    dayname text,
    dayinyear double precision
);


ALTER TABLE public.dimensionfecha OWNER TO postgres;

--
-- Name: dimensionfranquicia; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dimensionfranquicia (
    id integer,
    nombre character varying(40)
);


ALTER TABLE public.dimensionfranquicia OWNER TO postgres;

--
-- Name: dimensiongrupoedad; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dimensiongrupoedad (
    id double precision NOT NULL,
    nombre text
);


ALTER TABLE public.dimensiongrupoedad OWNER TO postgres;

--
-- Name: dimensionlocal; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dimensionlocal (
    id integer,
    codigo character varying(40),
    piso integer,
    sector character varying(30)
);


ALTER TABLE public.dimensionlocal OWNER TO postgres;

--
-- Name: dimensionmesa; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dimensionmesa (
    id integer NOT NULL
);


ALTER TABLE public.dimensionmesa OWNER TO postgres;

--
-- Name: dimensionpiso; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dimensionpiso (
    numero integer NOT NULL,
    nombre character varying(30)
);


ALTER TABLE public.dimensionpiso OWNER TO postgres;

--
-- Name: dimensionpuerta; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dimensionpuerta (
    puerta integer NOT NULL,
    localizacion character varying(40) NOT NULL,
    emergencia character varying(15) NOT NULL
);


ALTER TABLE public.dimensionpuerta OWNER TO postgres;

--
-- Name: dimensionsector; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dimensionsector (
    id integer NOT NULL,
    nombre character varying(30)
);


ALTER TABLE public.dimensionsector OWNER TO postgres;

--
-- Name: dimensionsexo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dimensionsexo (
    id double precision NOT NULL,
    nombre text
);


ALTER TABLE public.dimensionsexo OWNER TO postgres;

--
-- Name: flujodiariolocal; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.flujodiariolocal (
    local integer NOT NULL,
    dayinyear double precision NOT NULL,
    year double precision NOT NULL,
    flujo bigint
);


ALTER TABLE public.flujodiariolocal OWNER TO postgres;

--
-- Name: flujodiariosectorpiso; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.flujodiariosectorpiso (
    sector integer NOT NULL,
    piso integer NOT NULL,
    dayinyear double precision NOT NULL,
    year double precision NOT NULL,
    cantidad bigint
);


ALTER TABLE public.flujodiariosectorpiso OWNER TO postgres;

--
-- Name: tiempodiariomesaocupada; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tiempodiariomesaocupada (
    mesa integer NOT NULL,
    dayinyear double precision NOT NULL,
    year double precision NOT NULL,
    tiempo double precision
);


ALTER TABLE public.tiempodiariomesaocupada OWNER TO postgres;

--
-- Name: tiempomensualmesaocupada; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tiempomensualmesaocupada (
    mesa integer NOT NULL,
    month double precision NOT NULL,
    year double precision NOT NULL,
    tiempo double precision
);


ALTER TABLE public.tiempomensualmesaocupada OWNER TO postgres;

--
-- Name: ventasdiariasfranquicia; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ventasdiariasfranquicia (
    franquicia integer NOT NULL,
    dayinyear double precision NOT NULL,
    year smallint NOT NULL,
    monto double precision
);


ALTER TABLE public.ventasdiariasfranquicia OWNER TO postgres;

--
-- Name: ventasdiariaslocal; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ventasdiariaslocal (
    dayinyear double precision NOT NULL,
    year smallint NOT NULL,
    local integer NOT NULL,
    monto double precision
);


ALTER TABLE public.ventasdiariaslocal OWNER TO postgres;

--
-- Name: ventasdiariassectorpiso; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ventasdiariassectorpiso (
    sector integer NOT NULL,
    piso integer NOT NULL,
    dayinyear double precision NOT NULL,
    year smallint NOT NULL,
    monto double precision
);


ALTER TABLE public.ventasdiariassectorpiso OWNER TO postgres;

--
-- Name: ventasmensualesfranquicia; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ventasmensualesfranquicia (
    franquicia integer NOT NULL,
    month double precision NOT NULL,
    year double precision NOT NULL,
    monto double precision
);


ALTER TABLE public.ventasmensualesfranquicia OWNER TO postgres;

--
-- Name: ventasmensualeslocal; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ventasmensualeslocal (
    local integer NOT NULL,
    monto double precision,
    month double precision NOT NULL,
    year double precision NOT NULL
);


ALTER TABLE public.ventasmensualeslocal OWNER TO postgres;

--
-- Name: ventasmensualessectorpiso; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ventasmensualessectorpiso (
    sector integer NOT NULL,
    piso integer NOT NULL,
    month double precision NOT NULL,
    year double precision NOT NULL,
    monto double precision
);


ALTER TABLE public.ventasmensualessectorpiso OWNER TO postgres;

--
-- Data for Name: accesosdiariosedad; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.accesosdiariosedad (puerta, grupoedad, year, dayinyear, cantidad) FROM stdin;
\.
COPY public.accesosdiariosedad (puerta, grupoedad, year, dayinyear, cantidad) FROM '$$PATH$$/2949.dat';

--
-- Data for Name: accesosdiariosporsexo; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.accesosdiariosporsexo (puerta, year, dayinyear, sexo, cantidad) FROM stdin;
\.
COPY public.accesosdiariosporsexo (puerta, year, dayinyear, sexo, cantidad) FROM '$$PATH$$/2950.dat';

--
-- Data for Name: accesosdiariostotales; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.accesosdiariostotales (puerta, year, dayinyear, cantidad) FROM stdin;
\.
COPY public.accesosdiariostotales (puerta, year, dayinyear, cantidad) FROM '$$PATH$$/2951.dat';

--
-- Data for Name: accesosmensualedad; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.accesosmensualedad (puerta, grupoedad, year, month, cantidad) FROM stdin;
\.
COPY public.accesosmensualedad (puerta, grupoedad, year, month, cantidad) FROM '$$PATH$$/2952.dat';

--
-- Data for Name: accesosmensualporsexo; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.accesosmensualporsexo (puerta, year, month, sexo, cantidad) FROM stdin;
\.
COPY public.accesosmensualporsexo (puerta, year, month, sexo, cantidad) FROM '$$PATH$$/2953.dat';

--
-- Data for Name: accesosmensualtotales; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.accesosmensualtotales (puerta, year, month, cantidad) FROM stdin;
\.
COPY public.accesosmensualtotales (puerta, year, month, cantidad) FROM '$$PATH$$/2954.dat';

--
-- Data for Name: dimensionfecha; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dimensionfecha (dimensiondate, year, quarter, month, day, weekday, monthname, dayname, dayinyear) FROM stdin;
\.
COPY public.dimensionfecha (dimensiondate, year, quarter, month, day, weekday, monthname, dayname, dayinyear) FROM '$$PATH$$/2955.dat';

--
-- Data for Name: dimensionfranquicia; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dimensionfranquicia (id, nombre) FROM stdin;
\.
COPY public.dimensionfranquicia (id, nombre) FROM '$$PATH$$/2956.dat';

--
-- Data for Name: dimensiongrupoedad; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dimensiongrupoedad (id, nombre) FROM stdin;
\.
COPY public.dimensiongrupoedad (id, nombre) FROM '$$PATH$$/2957.dat';

--
-- Data for Name: dimensionlocal; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dimensionlocal (id, codigo, piso, sector) FROM stdin;
\.
COPY public.dimensionlocal (id, codigo, piso, sector) FROM '$$PATH$$/2958.dat';

--
-- Data for Name: dimensionmesa; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dimensionmesa (id) FROM stdin;
\.
COPY public.dimensionmesa (id) FROM '$$PATH$$/2959.dat';

--
-- Data for Name: dimensionpiso; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dimensionpiso (numero, nombre) FROM stdin;
\.
COPY public.dimensionpiso (numero, nombre) FROM '$$PATH$$/2960.dat';

--
-- Data for Name: dimensionpuerta; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dimensionpuerta (puerta, localizacion, emergencia) FROM stdin;
\.
COPY public.dimensionpuerta (puerta, localizacion, emergencia) FROM '$$PATH$$/2973.dat';

--
-- Data for Name: dimensionsector; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dimensionsector (id, nombre) FROM stdin;
\.
COPY public.dimensionsector (id, nombre) FROM '$$PATH$$/2961.dat';

--
-- Data for Name: dimensionsexo; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dimensionsexo (id, nombre) FROM stdin;
\.
COPY public.dimensionsexo (id, nombre) FROM '$$PATH$$/2962.dat';

--
-- Data for Name: flujodiariolocal; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.flujodiariolocal (local, dayinyear, year, flujo) FROM stdin;
\.
COPY public.flujodiariolocal (local, dayinyear, year, flujo) FROM '$$PATH$$/2963.dat';

--
-- Data for Name: flujodiariosectorpiso; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.flujodiariosectorpiso (sector, piso, dayinyear, year, cantidad) FROM stdin;
\.
COPY public.flujodiariosectorpiso (sector, piso, dayinyear, year, cantidad) FROM '$$PATH$$/2964.dat';

--
-- Data for Name: tiempodiariomesaocupada; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tiempodiariomesaocupada (mesa, dayinyear, year, tiempo) FROM stdin;
\.
COPY public.tiempodiariomesaocupada (mesa, dayinyear, year, tiempo) FROM '$$PATH$$/2965.dat';

--
-- Data for Name: tiempomensualmesaocupada; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tiempomensualmesaocupada (mesa, month, year, tiempo) FROM stdin;
\.
COPY public.tiempomensualmesaocupada (mesa, month, year, tiempo) FROM '$$PATH$$/2966.dat';

--
-- Data for Name: ventasdiariasfranquicia; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ventasdiariasfranquicia (franquicia, dayinyear, year, monto) FROM stdin;
\.
COPY public.ventasdiariasfranquicia (franquicia, dayinyear, year, monto) FROM '$$PATH$$/2967.dat';

--
-- Data for Name: ventasdiariaslocal; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ventasdiariaslocal (dayinyear, year, local, monto) FROM stdin;
\.
COPY public.ventasdiariaslocal (dayinyear, year, local, monto) FROM '$$PATH$$/2968.dat';

--
-- Data for Name: ventasdiariassectorpiso; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ventasdiariassectorpiso (sector, piso, dayinyear, year, monto) FROM stdin;
\.
COPY public.ventasdiariassectorpiso (sector, piso, dayinyear, year, monto) FROM '$$PATH$$/2969.dat';

--
-- Data for Name: ventasmensualesfranquicia; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ventasmensualesfranquicia (franquicia, month, year, monto) FROM stdin;
\.
COPY public.ventasmensualesfranquicia (franquicia, month, year, monto) FROM '$$PATH$$/2970.dat';

--
-- Data for Name: ventasmensualeslocal; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ventasmensualeslocal (local, monto, month, year) FROM stdin;
\.
COPY public.ventasmensualeslocal (local, monto, month, year) FROM '$$PATH$$/2971.dat';

--
-- Data for Name: ventasmensualessectorpiso; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ventasmensualessectorpiso (sector, piso, month, year, monto) FROM stdin;
\.
COPY public.ventasmensualessectorpiso (sector, piso, month, year, monto) FROM '$$PATH$$/2972.dat';

--
-- Name: accesosdiariosedad accesosdiariosedad_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accesosdiariosedad
    ADD CONSTRAINT accesosdiariosedad_pkey PRIMARY KEY (puerta, grupoedad, year, dayinyear);


--
-- Name: accesosdiariosporsexo accesosdiariosporsexo_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accesosdiariosporsexo
    ADD CONSTRAINT accesosdiariosporsexo_pkey PRIMARY KEY (puerta, sexo, year, dayinyear);


--
-- Name: accesosdiariostotales accesosdiariostotales_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accesosdiariostotales
    ADD CONSTRAINT accesosdiariostotales_pkey PRIMARY KEY (puerta, year, dayinyear);


--
-- Name: accesosmensualedad accesosmensualedad_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accesosmensualedad
    ADD CONSTRAINT accesosmensualedad_pkey PRIMARY KEY (puerta, grupoedad, year, month);


--
-- Name: accesosmensualporsexo accesosmensualporsexo_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accesosmensualporsexo
    ADD CONSTRAINT accesosmensualporsexo_pkey PRIMARY KEY (puerta, sexo, year, month);


--
-- Name: accesosmensualtotales accesosmensualtotales_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accesosmensualtotales
    ADD CONSTRAINT accesosmensualtotales_pkey PRIMARY KEY (puerta, year, month);


--
-- Name: dimensionfecha dimensionfecha_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dimensionfecha
    ADD CONSTRAINT dimensionfecha_pkey PRIMARY KEY (year, month, day);


--
-- Name: dimensiongrupoedad dimensiongrupoedad_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dimensiongrupoedad
    ADD CONSTRAINT dimensiongrupoedad_pkey PRIMARY KEY (id);


--
-- Name: dimensionmesa dimensionmesa_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dimensionmesa
    ADD CONSTRAINT dimensionmesa_pkey PRIMARY KEY (id);


--
-- Name: dimensionpiso dimensionpiso_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dimensionpiso
    ADD CONSTRAINT dimensionpiso_pkey PRIMARY KEY (numero);


--
-- Name: dimensionsector dimensionsector_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dimensionsector
    ADD CONSTRAINT dimensionsector_pkey PRIMARY KEY (id);


--
-- Name: dimensionsexo dimensionsexo_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dimensionsexo
    ADD CONSTRAINT dimensionsexo_pkey PRIMARY KEY (id);


--
-- Name: flujodiariolocal flujodiariolocal_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flujodiariolocal
    ADD CONSTRAINT flujodiariolocal_pkey PRIMARY KEY (local, dayinyear, year);


--
-- Name: flujodiariosectorpiso flujodiariosectorpiso_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flujodiariosectorpiso
    ADD CONSTRAINT flujodiariosectorpiso_pkey PRIMARY KEY (sector, piso, dayinyear, year);


--
-- Name: dimensionpuerta puerta_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dimensionpuerta
    ADD CONSTRAINT puerta_pkey PRIMARY KEY (puerta);


--
-- Name: tiempodiariomesaocupada tiempodiariomesaocupada_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tiempodiariomesaocupada
    ADD CONSTRAINT tiempodiariomesaocupada_pkey PRIMARY KEY (mesa, dayinyear, year);


--
-- Name: tiempomensualmesaocupada tiempomensualmesaocupada_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tiempomensualmesaocupada
    ADD CONSTRAINT tiempomensualmesaocupada_pkey PRIMARY KEY (mesa, month, year);


--
-- Name: ventasdiariasfranquicia ventasdiariasfranquicia_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ventasdiariasfranquicia
    ADD CONSTRAINT ventasdiariasfranquicia_pkey PRIMARY KEY (franquicia, dayinyear, year);


--
-- Name: ventasdiariaslocal ventasdiariaslocal_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ventasdiariaslocal
    ADD CONSTRAINT ventasdiariaslocal_pkey PRIMARY KEY (local, dayinyear, year);


--
-- Name: ventasdiariassectorpiso ventasdiariassectorpiso_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ventasdiariassectorpiso
    ADD CONSTRAINT ventasdiariassectorpiso_pkey PRIMARY KEY (sector, piso, dayinyear, year);


--
-- Name: ventasmensualesfranquicia ventasmensualesfranquicia_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ventasmensualesfranquicia
    ADD CONSTRAINT ventasmensualesfranquicia_pkey PRIMARY KEY (franquicia, month, year);


--
-- Name: ventasmensualeslocal ventasmensualeslocal_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ventasmensualeslocal
    ADD CONSTRAINT ventasmensualeslocal_pkey PRIMARY KEY (local, month, year);


--
-- Name: ventasmensualessectorpiso ventasmensualessectorpiso_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ventasmensualessectorpiso
    ADD CONSTRAINT ventasmensualessectorpiso_pkey PRIMARY KEY (sector, piso, month, year);


--
-- PostgreSQL database dump complete
--

